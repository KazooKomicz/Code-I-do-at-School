// DrawTriangle.ks
function main() {
    var canvas = document.getElementById('example')
    if(!canvas) {
        console.log('Failed to retrieve the <canvas> element');
        return;
    }
    //Get the rendering context 2dcg
    var ctx = canvas.getContext('2d');

    ctx.fillStyle = 'rgba(0 ,255, 0,1.0)'; //Set a blue color
    ctx.beginPath();
    ctx.moveTo(0,511);
    ctx.lineTo(256,0);
    ctx.lineTo(511,511);
    ctx.fill();
}