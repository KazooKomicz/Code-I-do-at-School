function main() {
    var canvas = document.getElementById("webgl");

    var gl = getWebGLContext(canvas);
    if(!gl) {alert("WebGL isn't available");}
    
    // Configure WebGL
    gl.viewport(0,0,canvas.width,canvas.height)
    gl.clearColor(1.0,1.0,1.0,1.0)

    var vshader = document.getElementById('vertex-shader').innerHTML
    var fshader = document.getElementById('fragment-shader').innerHTML

    // Load shaders and initialize attribute buffers
    var program = initShaders(gl,vshader,fshader);
    if(!program) {return;}

    //gl.useProgram(program);
    //gl.program = program;

    // Load the data into the GPU
    var bufferId = gl.createBuffer();
    if(!bufferId){
        console.log('Error: Failed to create the buffer object');
        return;
    }

    var vertices = new Float32Array([-1.0,-1.0,0.0,1.0,1.0,-1.0]);
    gl.bindBuffer(gl.ARRAY_BUFFER, bufferId);
    gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);

    // Associate out shader variables with our data buffer
    var aPosition = gl.getAttribLocation(gl.program,"a_Position");
    gl.vertexAttribPointer(aPosition, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(aPosition);

    render(gl);    
}

function render(gl) {
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
}