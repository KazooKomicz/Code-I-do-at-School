            _       _         /|   |````\
           | \     / |       / |   |     |
            \ \   / /       /  |   |----<
              )\-/(        /===|   |     |
              /O O\       /    |   |     |
             ( >Y< )     /     | o |____/ o
             /'-^-'\
        ____/ /___\ \
   \   /    ```   / ```~~"--.,_
`-._\ /          /          /   `~~"--.,_
----->|         /          /             `~~"--.,_
_.-'/ \          /          /                     ~~"--.,_
   /   \_________________________,,,,....----""""~~~~````

++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

So...teacher.

You have decided to give us a language that by all means should not be used for recursion, lists, and for the love of all things holy numbers and numerical equations. You even crippled us in this language for the sake of teaching and a 'learning experience' for this assignment. Curses on your golden oxes.


|||   WHAT I USED:    |||
(Basic Page) https://docs.racket-lang.org/guide/index.html
(Citation)   https://docs.racket-lang.org/reference/index.html
(Functions)  https://docs.racket-lang.org/guide/functions.html
(Iteration)  https://docs.racket-lang.org/guide/iteration.html
(Lists)      https://docs.racket-lang.org/reference/list.html
(Conditions) https://docs.racket-lang.org/guide/conditionals.html
(Func.Prog.)https://en.wikipedia.org/wiki/Functional_programming
(Mach. Lang.)https://en.wikipedia.org/wiki/Standard_ML
(For Loop)   https://docs.racket-lang.org/guide/for.html
(Let func.)  https://docs.racket-lang.org/guide/let.html
(Booleans)   https://docs.racket-lang.org/guide/booleans.html
(Recursion)  https://docs.racket-lang.org/guide/
Lists__Iteration__and_Recursion.html#%28part._.Recursion_versus_.Iteration%29

{I have the "for loop" page as a reference because I screwed up the first time, but the test cases made in that iteration still work well so I kept it.  
The reason I messed up is because I was not able to read it due to... brain cell loss in caffeinated vigor [Do Drugs Kids!]}

|||   HOW TO RUN MY PROGRAM (for idiots)   |||

1. Install Racket from this link 
---> (https://download.racket-lang.org/)
2. Follow this guide to get to DrRacket 
---> (https://docs.racket-lang.org/getting-started/)
3. Open the (.rkt) file included in the .zip by double click
4. Hit Run in the right top corner of DrRacket with the green arrow
5. Go down to the box with the ">" (or the "terminal" if you're feeling like your life needs more spice), click the space before the arrow
6. Copy/Paste the test case below in the space and hit the enter key. Voila!

There should be four messages that appear that show each of the programs run perfectly. If you want to try it out yourself feel free to call any function by typing it in parentheses and passing it through the "terminal".

Ex. > (is_older '(2002 10 4) '(2002 10 12))
			OR
    > (dates_in_month '((2023 5 21)(2024 3 15)(2006 5 8)) 5) 

---------------------------------------------------------
Here's what was supposed to be my (test.rkt) but DrRacket said no {feel free to examine, but the parts needed to copy/paste are marked for your convenience} :
---------------------------------------------------------
#lang racket
(require "progTwo.rkt") ;This does not work in a separate tab
;Alyssa Ballestro
;Started 9/9/2024  Finished 9/13/2024
;Programming Languages

;Test functions for file functions

#|============Copy/Paste into Terminal from here==============|#

(define (test_is_older) ;is_older
  (let ([result (is_older '(2000 5 15) '(2001 3 10))])
    (if (equal? result #t)
        (displayln "Test for is_older passed.")
        (displayln "Test for is_older failed."))))

(define (test_number_in_month) ;number_in_month
  (let ([result (number_in_month '((2023 5 15) (2024 5 22) (2024 3 5)) 5)])
    (if (equal? result 2)
        (displayln "Test for number_in_month passed.")
        (displayln "Test for number_in_month failed."))))

(define (test_number_in_months) ;number_in_months
  (let ([result (number_in_months '((2023 5 15) (2024 5 22) (2024 3 5)) '(5 3))])
    (if (equal? result 3)
        (displayln "Test for number_in_months passed.")
        (displayln "Test for number_in_months failed."))))

(define (test_dates_in_month) ;dates_in_month
  (let ([result (dates_in_month '((2023 5 15) (2024 5 22) (2024 3 5)) 5)])
    (if (equal? result '((2023 5 15) (2024 5 22)))
        (displayln "Test for dates_in_month passed.")
        (displayln "Test for dates_in_month failed."))))

; Call the test functions
(test_is_older)
(test_number_in_month)
(test_number_in_months)
(test_dates_in_month)
#|=========================To Here=======================|#
















































"lol, you've scrolled too far."
"Psst...This still works in Racket if you copy/paste."
