var s_point = []; // The array for the position of a mouse press
var g_points = []; // An array to store the position of mouse clicks
var lowestTime = Infinity; // Variable to store the lowest click time
var dotPlaced = false; // Flag to track if the dot has been placed
// Vertex shader program
var VSHADER_SOURCE =
  'attribute vec4 a_Position;\n' +
  'void main() {\n' +
  '  gl_Position = a_Position;\n' +
  '  gl_PointSize = 10.0;\n' +
  '}\n';

// Fragment shader program
var FSHADER_SOURCE =
  'void main() {\n' +
  '  gl_FragColor = vec4(1.0, 0.0, 0.0, 1.0);\n' +
  '}\n';
function main() {
  // Get the WebGL rendering context
  var canvas = document.getElementById('webgl');
  var gl = getWebGLContext(canvas);
  if (!gl) {
    console.log('WebGL is not supported.');
    return;
  }

  // Initialize shaders and get attribute location
  if (!initShaders(gl, VSHADER_SOURCE, FSHADER_SOURCE)) {
    console.log('Failed to initialize shaders.');
    return;
  }
  var a_Position = gl.getAttribLocation(gl.program, 'a_Position');
  if (a_Position < 0) {
    console.log('Failed to get the storage location of a_Position');
    return;
  }

  // Generate random coordinates for the dot and draw it
  var x = Math.random() * 2 - 1; // Random x coordinate between -1 and 1
  var y = Math.random() * 2 - 1; // Random y coordinate between -1 and 1
  g_points.push(x, y);
  gl.clear(gl.COLOR_BUFFER_BIT);
  gl.vertexAttrib2f(a_Position, x, y);
  gl.drawArrays(gl.POINTS, 0, 1);

  // Register a click event handler for the canvas
  canvas.onmousedown = function (ev) {
    click(ev, gl, canvas, a_Position);
  };
  
}

var count = 0;
function click(ev, gl, canvas, a_Position) {
  var x = ev.clientX; // x coordinate of a mouse pointer
  var y = ev.clientY; // y coordinate of a mouse pointer
  var rect = ev.target.getBoundingClientRect();
  var best = document.getElementById("BestTimeValue");
  var cur = document.getElementById("CurrentTimeValue");
  
  x = ((x - rect.left) - canvas.width / 2) / (canvas.width / 2);
  y = (canvas.height / 2 - (y - rect.top)) / (canvas.height / 2);
  
  if (!dotPlaced) {
    // Place the location of the dot
	g_points.push(x, y);
	
    // Clear <canvas>
    gl.clear(gl.COLOR_BUFFER_BIT);

    // Pass the position of a point to a_Position variable
    gl.vertexAttrib2f(a_Position, x, y);

    // Draw the dot
    gl.drawArrays(gl.POINTS, 0, 1);

    // Record the time when the dot is placed
    s_point.push(performance.now());
    dotPlaced = true;
  } else if(count < 10) {
    // When click event occurs, remove the dot
    gl.clear(gl.COLOR_BUFFER_BIT);

    // Check if the click is within the dot's radius (assuming dot size)
    var distance = Math.sqrt(Math.pow(g_points[0] - x, 2) + Math.pow(g_points[1] - y, 2));
	//Checks click if on or not
    if (distance < 0.1) { // Adjust the value based on your dot size
      // Calculate the time elapsed since dot placement
      var clickTime = performance.now() - s_point[0];

      // Compare time to the lowest and update if better
      if (clickTime < lowestTime) {
        lowestTime = clickTime;
      }

      // Report the click time and lowest time
      console.log(`Click Time: ${clickTime.toFixed(2)} ms`);
	  cur.textContent = clickTime.toFixed(2);
	  best.textContent = lowestTime.toFixed(2);

      // Reset the dot placement flag
      dotPlaced = false;

      // Clear the recorded points and times
      g_points.length = 0;
      s_point.length = 0;

      // Generate new random coordinates for the dot and draw it
      var newX = Math.random() * 2 - 1; // Random x coordinate between -1 and 1
      var newY = Math.random() * 2 - 1; // Random y coordinate between -1 and 1
      g_points.push(newX, newY);
      gl.vertexAttrib2f(a_Position, newX, newY);
      gl.drawArrays(gl.POINTS, 0, 1);

      // Record the time when the new dot is placed
      s_point.push(performance.now());
      dotPlaced = true;
	  count += 1;
    } else {
      // If the click is outside the dot, consider it a miss and reset
      console.log("Missed the dot. Reset at point.");
      dotPlaced = false;
      g_points.length = 0;
      s_point.length = 0;
    }
	
  } else if(count == 10) {
	  console.log(`Lowest Time: ${lowestTime.toFixed(2)} ms`);
	  

  }
}

window.onload = main;
